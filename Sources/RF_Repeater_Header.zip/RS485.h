#ifndef	__RS485_H
#define	__RS485_H
#include "main.h"

#define	URX1_LEN		512
#define	UTX1_LEN		512

void USART1_IRQ_Function(void);
void Rs485_proc(void);
void Send_Password(void);
void Send_Warnoff(void);
void Send_DateTime(void);
void Request_Status(void);
void Receive_0xB1(void);
void Receive_0xA2(void);
void Card_Batch_proc(void);
void Card_info_read(void);

void SendChar1(uint8_t send_c);
void mprintf1(const char *format, ...);


#endif
