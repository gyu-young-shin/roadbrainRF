#ifndef	__W5100S_H
#define	__W5100S_H
#include "main.h"

#define ETH_MAX_BUF_SIZE	2048
#define TCP_SOCKET_PORT_NUM	38000

#define	_TCPSERVER_DEBUG_

/* DATA_BUF_SIZE define for Loopback example */
#ifndef DATA_BUF_SIZE
	#define DATA_BUF_SIZE			2048
#endif



typedef __packed struct {
	uint8_t		stx_char;
	uint16_t	data_len;
	uint8_t		command;
	uint16_t	goup_id;
	uint16_t	master_id;
}TStatus_header_rec;

typedef __packed struct {
	uint8_t		slave_id;
	uint8_t		status;
	uint16_t	battery_status;
}TStatus_rec;


typedef __packed struct {
	uint16_t	card_num;
	uint32_t	card_data;
}TCarddata_rec;


void Wiznet_W5100S_Init(void);
void Set_MAC_Address(void);
void Tcp_Proc(void);
void Tcp_Server_Proc(uint8_t sn, uint8_t* buf, uint16_t port);
void Tcp_Client_Proc(void);
void print_network_information(void);

void RF_Answer(uint8_t sn);
void Master_NFC_Answer(uint8_t sn);
void Answer_SetPassword(uint8_t sn);
void Answer_Controle(uint8_t sn, uint8_t command, uint8_t slave_id, uint8_t result_var);
void Answer_CardRequest(uint8_t sn, uint8_t command, uint8_t result_var);
void Answer_CardInfo(uint8_t sn);
void Answer_CardData(uint8_t sn);

void Master_Card_Read(void);
void Master_Card_Write(void);
void Answer_PeriodTime(uint8_t sn);
void Send_Status(uint8_t sn, uint8_t command, uint8_t slave_id);
void DateTime_Update(void);
void Send_Maintain_Packet(uint8_t sn);
void DNS_Proc(void);
void Ethernet_Proc(uint8_t sn, int32_t recv_len);
uint16_t Swap_int16(uint16_t swap_var);
uint32_t Swap_int32(uint32_t swap_var);




void dhcp_assign(void);
void dhcp_update(void);
void dhcp_conflict(void);



#endif
