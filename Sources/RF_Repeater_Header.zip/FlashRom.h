#ifndef	__FLASHROM_H
#define	__FLASHROM_H

#include "main.h"
// STM32F103VCT6
#define FLASH_CONF_START_ADDR	0x0803C000		// 8K			��� ���� ����
#define FLASH_DATA_SIZE			0x2000			// 8K

#define FLASH_CARD_LIST_ADDR	0x0803E000		// 4K			Card List Header
#define FLASH_CARD_DATA_SIZE	0x1000			// 4K			Card List Header

#define FLASH_CARD_BANK1_ADDR	0x0803F000		// 2K			Card Data
#define FLASH_CARD_BANK2_ADDR	0x0803F800		// 2K


typedef struct
{
	uint32_t   	e2p_offset_addr;	// Offset Address

	uint16_t   	e2p_group_id;		// Group ID		0000-9999
	uint16_t   	e2p_master_id;		// Master Id    0000-9999

	uint16_t	e2p_id;				// Identification  0���� ��� master, 1-100 Slave
	uint8_t		model;				// 1:Master, 0:Slave
	uint8_t		e2p_slave_count;	// Master �ϰ�� ����� Salve�� ���� 1-100

	uint8_t		si_ch;				// si4463 Channel Number 0-9
	uint8_t		si_db;				// si4463 DB
	uint8_t		e2p_statustime;		// ���� ������ �����ֱ� (Master �� ���)
	uint8_t		e2p_protocol;		// 0: Old Version, 1: New Version
	
	uint8_t		e2p_ipkind;			// 0: IP Address, 1: DNS Server
	uint8_t		e2p_ncnokind;		// 0: Emg Door, 1: EM-Lock
	uint8_t		e2p_rssi;			// rssi ���� ���ذ�
	uint8_t		pad;
	
} TE2PDataRec;


typedef struct
{
	uint32_t   	e2p_offset_addr;	// Offset Address

	uint32_t	e2p_bank_num;		// Card Data Bank number
	uint32_t	e2p_card_used[16];	// 4 * 16 = 64Byte 64 * 8bit = 512bit
} TCardlistrec;

void FlashRom_Init(void);
void FlashRom_WriteData(void);
void FlashCard_Init(void);
void FlashCard_WriteData(void);
void FlashCard_DataMove(uint8_t	Move_kind);
void Flash_Erash_Page(uint32_t Address);

#endif
