#ifndef	__MYTIMER_H
#define	__MYTIMER_H


void Systic_Callback_Proc(void);
void Timer_Proc(void);
void Key_Scan(void);
void Network_state_led(void);


#endif
